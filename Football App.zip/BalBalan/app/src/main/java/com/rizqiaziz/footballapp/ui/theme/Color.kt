package com.rizqiaziz.footballapp.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFF4A00F7)
val PurpleGrey80 = Color(0xFF6000FA)
val Pink80 = Color(0xFFF50047)

val Purple40 = Color(0xFF440BE4)
val PurpleGrey40 = Color(0xFF6D34E7)
val Pink40 = Color(0xFFC72F61)